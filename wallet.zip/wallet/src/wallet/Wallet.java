package wallet;

import java.util.Map;

/**
 * Interfaz que representa una billetera.
 */
public interface Wallet {

    /**
     * Obtiene todos los saldos de la billetera.
     * 
     * @return Un mapa que mapea las monedas a los saldos correspondientes.
     */
    Map<String, Double> getAllBalances();

    /**
     * Obtiene el saldo de una moneda específica en la billetera.
     * 
     * @param currency La moneda de la cual se desea obtener el saldo.
     * @return El saldo de la moneda especificada.
     */
    double getBalance(String currency);

    /**
     * Realiza un depósito en la billetera en la moneda especificada.
     * 
     * @param amount   La cantidad a depositar.
     * @param currency La moneda en la que se realiza el depósito.
     */
    void deposit(double amount, String currency);

    /**
     * Realiza un retiro de la billetera en la moneda especificada.
     * 
     * @param amount   La cantidad a retirar.
     * @param currency La moneda en la que se realiza el retiro.
     * @throws InsufficientFundsException Si no hay suficientes fondos en la moneda especificada.
     */
    void withdraw(double amount, String currency) throws InsufficientFundsException;

    /**
     * Convierte una cantidad de una moneda a otra en la billetera.
     * 
     * @param amount       La cantidad a convertir.
     * @param fromCurrency La moneda de origen.
     * @param toCurrency   La moneda de destino.
     * @throws CurrencyConversionException Si hay un error durante la conversión de moneda.
     * @throws InsufficientFundsException 
     */
    void convertCurrency(double amount, String fromCurrency, String toCurrency) throws CurrencyConversionException, InsufficientFundsException;
}
