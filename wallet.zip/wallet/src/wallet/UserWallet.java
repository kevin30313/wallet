package wallet;

import java.util.HashMap;
import java.util.Map;

public class UserWallet implements Wallet {
    private Map<String, Double> balances;
    private Map<String, Double> exchangeRates;
   

    public UserWallet() {
        this.balances = new HashMap<>();
        this.exchangeRates = new HashMap<>();
        initializeExchangeRates(); // Inicializar saldos y tasas de cambio con valores iniciales
    }

    private void initializeExchangeRates() {
        // Inicializar saldos con valor 0 para todas las monedas
        this.balances.put("USD", 0.0);
        this.balances.put("EUR", 0.0);
        this.balances.put("GBP", 0.0);
        this.balances.put("CLP", 0.0);
        this.balances.put("KRW", 0.0);
        this.balances.put("JPY", 0.0);
        this.balances.put("CNY", 0.0);
        this.balances.put("AUD", 0.0);
        this.balances.put("MXN", 0.0);
        this.balances.put("BRL", 0.0);
        this.balances.put("ARS", 0.0);
        this.balances.put("COP", 0.0);
        this.balances.put("PHP", 0.0);
        this.balances.put("VND", 0.0);
        this.balances.put("SAR", 0.0);
        this.balances.put("AED", 0.0);
        
        // Inicializar tasas de cambio
        // Conversiones directas a CLP
     // Actualizar tasas de cambio con los valores proporcionados
        this.exchangeRates.put("USD", 1 / 926.0);
        this.exchangeRates.put("EUR", 1 / 997.55);
        // Resto de las tasas proporcionadas
        this.exchangeRates.put("GBP", 0.75);
        this.exchangeRates.put("KRW", 1169.73);
        this.exchangeRates.put("JPY", 117.51);
        this.exchangeRates.put("CNY", 6.36);
        this.exchangeRates.put("AUD", 1.35);
        this.exchangeRates.put("MXN", 20.26);
        this.exchangeRates.put("BRL", 5.36);
        this.exchangeRates.put("ARS", 106.50);
        this.exchangeRates.put("COP", 3843.33);
        this.exchangeRates.put("PHP", 50.30);
        this.exchangeRates.put("VND", 23100.0);
        this.exchangeRates.put("SAR", 3.75);
        this.exchangeRates.put("AED", 3.67);
    }

    @Override
    public Map<String, Double> getAllBalances() {
        Map<String, Double> convertedBalances = new HashMap<>();
        for (String currency : balances.keySet()) {
            double balance = balances.get(currency);
            double exchangeRate = exchangeRates.getOrDefault(currency, 1.0); // Si no hay tasa de cambio, usar 1.0 como valor predeterminado
            double equivalentAmount = balance * exchangeRate; // No es necesario multiplicar por ufToCLP ya que el saldo se da en la moneda correspondiente
            convertedBalances.put(currency, equivalentAmount);
        }
        return convertedBalances;
    }

    @Override
    public void deposit(double amount, String currency) {
        double currentBalance = this.balances.getOrDefault(currency, 0.0);
        this.balances.put(currency, currentBalance + amount);
    }

    @Override
    public void withdraw(double amount, String currency) throws InsufficientFundsException {
        double currentBalance = this.balances.get(currency);
        if (amount > currentBalance) {
            throw new InsufficientFundsException(currency);
        }
        this.balances.put(currency, currentBalance - amount);
    }

    @Override
    public void convertCurrency(double amount, String fromCurrency, String toCurrency) throws CurrencyConversionException, InsufficientFundsException {
        double fromBalance = this.balances.getOrDefault(fromCurrency, 0.0);
        double toBalance = this.balances.getOrDefault(toCurrency, 0.0);
        double exchangeRate;

        if (fromBalance < amount) {
            throw new InsufficientFundsException("Saldo insuficiente en la moneda de origen.");
        }

        if (fromCurrency.equals("CLP")) {
            exchangeRate = exchangeRates.getOrDefault(toCurrency, 0.0); // Tasa de cambio directa desde CLP
        } else if (toCurrency.equals("CLP")) {
            exchangeRate = 1 / exchangeRates.getOrDefault(fromCurrency, 0.0); // Tasa de cambio inversa hacia CLP
        } else {
            // Tasa de cambio entre otras monedas
            exchangeRate = exchangeRates.getOrDefault(toCurrency, 0.0) / exchangeRates.getOrDefault(fromCurrency, 1.0);
        }

        double equivalentAmount = amount * exchangeRate;

        // Actualizar saldos de las monedas involucradas
        this.balances.put(fromCurrency, fromBalance - amount);
        this.balances.put(toCurrency, toBalance + equivalentAmount);
    }


    @Override
    public double getBalance(String currency) {
        return this.balances.getOrDefault(currency, 0.0);
    }
    }
