package wallet;

import java.util.Scanner;

public class AlkeWalletApp {
    private static Scanner scanner;
    private static Wallet userWallet;

    public AlkeWalletApp() {
        scanner = new Scanner(System.in);
        userWallet = new UserWallet(); // Instancia de la billetera del usuario
    }

    public void start() {
        boolean running = true;

        while (running) {
            printMenu();
            int option = scanner.nextInt();
            scanner.nextLine(); 

            switch (option) {
                case 1:
                    showBalance();
                    break;
                case 2:
                    performDeposit();
                    break;
                case 3:
                    performWithdrawal();
                    break;
                case 4:
                    perfomCurrencyConversion();
                    break;
                case 5:
                    System.out.println("Gracias por usar Alke Wallet. ¡Hasta luego!");
                    running = false;
                    break;
                default:
                    System.out.println("Opción no válida.");
                    break;
            }
        }

        scanner.close();
    }

    private void printMenu() {
        System.out.println("Bienvenido a Alke Wallet");
        System.out.println("1. Ver saldo");
        System.out.println("2. Realizar depósito");
        System.out.println("3. Realizar retiro");
        System.out.println("4. Convertir moneda");
        System.out.println("5. Salir");
        System.out.print("Seleccione una opción: ");
    }

    private void showBalance() {
        System.out.println("Saldo disponible:");
        for (String currency : userWallet.getAllBalances().keySet()) {
            System.out.println(currency + ": " + userWallet.getBalance(currency));
        }
    }

    private void performDeposit() {
        System.out.print("Ingrese la cantidad a depositar: ");
        double depositAmount = scanner.nextDouble();
        scanner.nextLine(); // Consumir el salto de línea
        System.out.print("Ingrese la moneda (USD, EUR, etc.): ");
        String currency = scanner.nextLine().toUpperCase();
        userWallet.deposit(depositAmount, currency);
        System.out.println("Depósito realizado con éxito.");
    }

    private void performWithdrawal() {
        System.out.print("Ingrese la cantidad a retirar: ");
        double withdrawAmount = scanner.nextDouble();
        scanner.nextLine(); 
        
        System.out.print("Ingrese la moneda (USD, EUR, etc.): ");
        String currency = scanner.nextLine().toUpperCase();
        
        try {
            userWallet.withdraw(withdrawAmount, currency);
            System.out.println("Retiro realizado con éxito.");
        } catch (InsufficientFundsException e) {
            System.out.println("Error: Fondos insuficientes.");
            }
        }
    
    private static void perfomCurrencyConversion() {
    try {
        System.out.print("Ingrese la cantidad a convertir: ");
        double amount = scanner.nextDouble();
        scanner.nextLine();  // Consume the newline character
        System.out.print("Ingrese la moneda de origen (USD, EUR, etc.): ");
        String fromCurrency = scanner.nextLine();
        System.out.print("Ingrese la moneda de destino (USD, EUR, etc.): ");
        String toCurrency = scanner.nextLine();
        userWallet.convertCurrency(amount, fromCurrency, toCurrency);
        System.out.println("Conversión realizada con éxito.");
    } catch (CurrencyConversionException e) {
        System.out.println("Error al convertir moneda: " + e.getMessage());
    } catch (InsufficientFundsException e) {
        System.out.println("Error: Saldo insuficiente en la moneda de origen.");
    }

}}
