package wallet.test;

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import wallet.CurrencyConversionException;
import wallet.InsufficientFundsException;
import wallet.UserWallet;

public class UserWalletTest {
    private UserWallet userWallet;

    @BeforeClass
    public static void setUpBeforeClass() throws Exception {
        // Código de inicialización que se ejecuta una vez antes de todas las pruebas
    }

    @AfterClass
    public static void tearDownAfterClass() throws Exception {
        // Código de limpieza que se ejecuta una vez después de todas las pruebas
    }

    @Before
    public void setUp() throws Exception {
        // Código de inicialización que se ejecuta antes de cada prueba
        userWallet = new UserWallet();
    }

    @After
    public void tearDown() throws Exception {
        // Código de limpieza que se ejecuta después de cada prueba
        userWallet = null;
    }
    @Test
    public void testDeposit() {
        // Given
        double initialBalance = userWallet.getBalance("USD");

        // When
        userWallet.deposit(200, "USD");

        // Then
        assertEquals(initialBalance + 200, userWallet.getBalance("USD"), 0.001);
    }

    @Test
    public void testWithdraw() throws InsufficientFundsException {
        // Given
        userWallet.deposit(500, "USD");
        double initialBalance = userWallet.getBalance("USD");

        // When
        userWallet.withdraw(200, "USD");

        // Then
        assertEquals(initialBalance - 200, userWallet.getBalance("USD"), 0.001);
    }

    @Test
    public void testConvertCurrency() throws CurrencyConversionException, InsufficientFundsException {
        // Given
        userWallet.deposit(200, "EUR");

        // When
        userWallet.convertCurrency(200, "EUR", "CLP");

        // Then
        assertEquals(0, userWallet.getBalance("EUR"), 0.001);
        assertEquals(199510.0, userWallet.getBalance("CLP"), 0.001);
    }
}