package wallet;

public class Main {
    public static void main(String[] args) {
        AlkeWalletApp app = new AlkeWalletApp();
        app.start();
    }
}
